var div = document.getElementById("profileData");
    var data = localStorage.getItem("signupData");

if (data) {
  var d = JSON.parse(data);
  div.innerHTML =
    "<p><b>First Name:</b> " + d.firstName + "</p>" +
    "<p><b>Last Name:</b> " + d.lastName + "</p>" +
    "<p><b>Sex:</b> " + d.sex + "</p>" +
    "<p><b>Email:</b> " + d.email + "</p>" +
    "<p><b>Contact Number:</b> " + (d.contactNumber || "N/A") + "</p>" +
    "<p><b>Why Support:</b> " + d.supportReason + "</p>";
  } else {
    div.innerHTML = "<p>No data found. Please <a href='proj_signup_lastname.html'>sign up</a> first.</p>";
  }