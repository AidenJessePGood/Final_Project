document.getElementById('signupForm').addEventListener('submit', function(e) {
e.preventDefault();

const formData = {
  firstName: this.firstName.value.trim(),
  lastName: this.lastName.value.trim(),
  sex: this.sex.value,
  email: this.email.value.trim(),
  password: this.password.value,
  contactNumber: this.contactNumber.value.trim(),
  supportReason: this.supportReason.value.trim()
  };

  localStorage.setItem('signupData', JSON.stringify(formData));
  window.location.href = 'proj_profile_lastname.html';
})

